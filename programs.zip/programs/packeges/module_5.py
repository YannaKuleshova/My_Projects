# File "module_5.py"
# Path "D:\PYTHON\programs\packeges\"

# ----- Logging -----
import logging

def logger_ini():
        # Формат вывода текста в лог-файле.
        FORMAT = '%(name)s:\n%(levelname)s:\n%(asctime)s' 

        logger = logging.getLogger(__name__)
        # Запись данных в лог-файл.
        handler = logging.FileHandler('D:/PYTHON/My_Projects__/ToDoList.log', mode = 'w')
        handler.setLevel(logging.CRITICAL)

        formatter = logging.Formatter(FORMAT)
        handler.setFormatter(formatter)

        logger.addHandler(handler)

        logger.critical('CRITICAL message')
        logger.error('ERROR message')
        logger.warning('WARNING message')
        logger.info('INFO message')
        logger.debug('DEBUG message')

if __name__ == "__ToDo__":
        pass
